package com.aquila;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BateleurApplicationTests {

	@Test
	void contextLoads() {
	}

}
